using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InGameUIManager : MonoBehaviour
{
    [SerializeField] private Text Scoretxt;
    [SerializeField] private Text Cointxt;

    private void Update()
    {
        Scoretxt.text = "���� : " + DataManager.Instance.score.ToString();
        Cointxt.text = "���� ���� : " + DataManager.Instance.coin.ToString();
    }

}
