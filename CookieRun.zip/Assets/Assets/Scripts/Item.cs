using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    private float timer;
    private float delay = .2f;

    public GameObject Magneticitem;

    private void Update()
    {
        timer += Time.deltaTime;
        if (timer >= delay)
        {
            timer -= delay;
            if (Random.Range(0f, 500f) < 10f && GameManager.instance.isPlay)
            {
                GameObject item = Instantiate(Magneticitem);
                item.transform.position = new Vector3(11, Random.Range(-3f, 7f), 0);
                if (item.transform.position.x < -11)
                {
                    Destroy(item);
                }
            }
        }
    }
}
