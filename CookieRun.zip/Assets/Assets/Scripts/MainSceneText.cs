using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainSceneText : MonoBehaviour
{
    [SerializeField] private Text highScoretxt;
    [SerializeField] private Text Cointxt;

    private void Update()
    {
        int highScore = DataManager.Instance.highScore;
        highScoretxt.text = "�ְ� ���� : " + highScore.ToString();
        Cointxt.text = "���� ���� : " + DataManager.Instance.coin.ToString();
    }
}
