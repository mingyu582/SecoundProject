using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SkipScenes : MonoBehaviour
{

    public void MailSceneChange() 
    {
        SceneManager.LoadScene("MailScene");
    }
    public void MainSceneChange() 
    {
        SceneManager.LoadScene("MainScene");
    }
    public void StoreSceneChange()
    {
        SceneManager.LoadScene("StoreScene");
    }
    public void BuySceneChange()
    {
        SceneManager.LoadScene("BuyScene");
    }
    public void BuySceneChange2()
    {
        SceneManager.LoadScene("BuyScene2");
    }
    public void BuySceneChange3()
    {
        SceneManager.LoadScene("BuyScene3");
    }
    public void InGameSceneChange() 
    {
        SceneManager.LoadScene("InGameScene");
        DataManager.Instance.StartGame(); 
    }
    public void SettingSceneChange() 
    {
        SceneManager.LoadScene("SettingScene");
    }
}
