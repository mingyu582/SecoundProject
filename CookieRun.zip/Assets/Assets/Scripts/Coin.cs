using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    private float timer;
    private float delay = .2f;

    public GameObject coin;

    private void Update()
    {
        timer += Time.deltaTime;
        if (timer >= delay) 
        {
            timer -= delay;
            if (Random.Range(0f, 100f) < 10f && GameManager.instance.isPlay) 
            {
                GameObject item = Instantiate(coin);
                item.transform.position = new Vector3(11, Random.Range(-3f, -7f), 0);
                if (item.transform.position.x < -11) 
                {
                    Destroy(item);
                }
            }
        }
    }
}
