using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    private Animator anim;

    private bool isJump = false;
    private bool isTop = false;
    private bool isGameOver = true;

    public float jumpHeight = 0;
    public float jumpSpeed = 0;

    Vector2 startPostion;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        startPostion = transform.position;
    }

    private void Update()
    {      
        PlayerJump();
        
        if (GameManager.instance.isPlay && DataManager.Instance.score >= 10000) 
        {
            GameManager.instance.gameSpeed = 10;
            
        }
        if (GameManager.instance.isPlay && DataManager.Instance.score >= 20000)
        {
            GameManager.instance.gameSpeed = 15;
        }
        if (GameManager.instance.isPlay && DataManager.Instance.score >= 30000)
        {
            GameManager.instance.gameSpeed = 20;
        }
        if (GameManager.instance.isPlay && DataManager.Instance.score >= 40000)
        {
            GameManager.instance.gameSpeed = 25;
        }
        if (GameManager.instance.isPlay && DataManager.Instance.score >= 50000)
        {
            GameManager.instance.gameSpeed = 100;
        }
    }

    public void PlayerJump() 
    {
        if (Input.GetKeyDown(KeyCode.Space) && GameManager.instance.isPlay)
        {
            isJump = true;
            isGameOver = false;
            anim.SetBool("Jump", isJump);
        }
        else if (transform.position.y <= startPostion.y)
        {
            isJump = false;
            isTop = false;
            isGameOver = true;
            anim.SetBool("Jump", isJump);
            transform.position = startPostion;
        }

        if (isJump)
        {
            if (transform.position.y <= jumpHeight - 0.1f && !isTop)
            {
                transform.position = Vector2.Lerp(transform.position, new Vector2(transform.position.x, jumpHeight), jumpSpeed * Time.deltaTime);
            }
            else
            {
                isTop = true;
            }
            if (transform.position.y > startPostion.y && isTop)
            {
                transform.position = Vector2.MoveTowards(transform.position, startPostion, jumpSpeed * Time.deltaTime);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Mob")) 
        {
            isGameOver = false;
            GameManager.instance.GameOver();
            anim.SetBool("GameOver", true);
            SceneManager.LoadScene("GameOverScene");
            DataManager.Instance.FinishGame();
        }
    }
}
